# Evaluation-only policy exception for the exact private fixture. Never deploy.
from urllib.parse import urlsplit
from dethrottled import research, server
original = research.public_url
research.public_url = lambda url: (urlsplit(url).hostname == 'dethrottled-dependable-fixture' and urlsplit(url).port == 19890) or original(url)
server.index_fetched = lambda *a, **k: 0
app = server.app
