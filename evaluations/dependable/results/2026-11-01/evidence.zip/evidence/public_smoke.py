from pathlib import Path
import hashlib,json,re,time,uuid
import httpx
ROOT=Path('/home/adminion/Documents/Codex/2026-10-31/hi/work/dethrottled-dependable');records=[]
registry=json.loads(Path('/etc/dethrottled-access/tokens.json').read_text());digests={t['sha256'] for t in registry['tokens']}
token=next(t for t in re.findall(r'Bearer\s+([A-Za-z0-9._~-]+)',Path('/etc/caddy/internal-mcp-secret.caddy').read_text()) if hashlib.sha256(t.encode()).hexdigest() in digests)
HEADERS={'Authorization':'Bearer '+token,'User-Agent':'dethrottled-remote-integration-audit/1.0','Accept':'application/json, text/event-stream'}
def save():
 (ROOT/'public-probes.json').write_text(json.dumps(records,indent=2,ensure_ascii=False))
def http(client,label,url,payload=None,auth=False):
 start=time.perf_counter()
 try:
  response=client.request('POST' if payload is not None else 'GET',url,json=payload,headers=HEADERS if auth else None)
  elapsed=round((time.perf_counter()-start)*1000,2)
  try:body=response.json()
  except ValueError:body={'non_json':response.text[:500]}
  row={'label':label,'url':url,'input':payload,'status':response.status_code,'wall_ms':elapsed,'http_version':response.http_version,'headers':{k:v for k,v in response.headers.items() if k.lower() in {'x-request-id','cf-ray','cf-cache-status','server-timing','retry-after','content-type'}},'response':body}
 except Exception as exc:row={'label':label,'url':url,'input':payload,'error':type(exc).__name__+': '+str(exc),'wall_ms':round((time.perf_counter()-start)*1000,2)}
 records.append(row);save();print(label,row.get('status'),row['wall_ms'],flush=True);return row.get('response',{})
def rpc(client,label,method,params,base='https://api.halonyx.io/mcp'):
 body=http(client,label,base,{'jsonrpc':'2.0','id':uuid.uuid4().hex,'method':method,'params':params},True)
 return body.get('result',{})
def tool(client,label,name,args):return rpc(client,label,'tools/call',{'name':name,'arguments':args})

with httpx.Client(trust_env=False,timeout=2) as local_ready:
 for _ in range(30):
  try:
   if all(local_ready.get('http://127.0.0.1:'+str(port)+'/health').status_code==200 for port in [8787,18184,18186]):break
  except httpx.HTTPError:pass
  time.sleep(1)
( ROOT/'live-token').write_text(token);(ROOT/'live-token').chmod(0o600)
def value(result):
 if result.get('isError'):raise AssertionError(result)
 r=result.get('structuredContent')
 if r is None:r=json.loads(result['content'][0]['text'])
 if isinstance(r,dict) and 'result' in r:r=r['result']
 return r[0] if isinstance(r,list) else r
with httpx.Client(trust_env=False,timeout=600) as public:
 init=rpc(public,'public-initialize','initialize',{'protocolVersion':'2025-03-26','capabilities':{},'clientInfo':{'name':'six-upgrade-smoke','version':'1'}})
 listing=rpc(public,'public-tools-list','tools/list',{});names={t['name'] for t in listing['tools']}
 assert {'inspect_document','crawl_site','resume_fetch_job'}<=names
 caps=value(tool(public,'public-capabilities','capabilities',{}))
 assert caps['version']=='0.7.0' and caps['read']['speech_worker_configured']
 assert caps['read']['layout_worker_configured']
 assert 'indexed_db' in caps['manipulation']['checkpoint']['state']
 assert {'tabs','switch_tab','history'} <= set(caps['manipulation']['actions'])
 assert set(caps['optional_search_providers']) == {'exa','tavily','parallel'}
 assert hashlib.sha256(init['instructions'].encode()).hexdigest()==caps['client_contract']['workflow_sha256']
 row=value(tool(public,'public-fetch','fetch',{'urls':['https://docs.python.org/3/library/sqlite3.html'],'max_chars':2000,'recovery':'manual'}))
 assert row['quality']=='ok' and row.get('document_id')
 blocks=value(tool(public,'public-inspect-document','inspect_document',{'document_id':row['document_id'],'limit':3}))
 assert blocks['blocks'] and blocks['document_sha256']==row['document_sha256']
 cross=http(public,'public-rest-read-mcp-document','https://api.halonyx.io/documents/read',{'document_id':row['document_id'],'max_chars':1000},True)
 assert cross.get('document_sha256')==row['document_sha256']
 site=value(tool(public,'public-site-crawl','crawl_site',{'urls':['https://docs.python.org/3/library/sqlite3.html'],'max_pages':1,'max_depth':0,'render':'never'}))
 assert site['coverage']['attempted']==1 and site['coverage']['succeeded']==1
 search=value(tool(public,'public-fresh-search','search',{'query':'Python sqlite3 official documentation','limit':5,'profile':'web','fresh':True,'diagnostics':True}))
 assert len(search['results'])>=3
 audio=value(tool(public,'public-audio-fetch','fetch',{'urls':['https://raw.githubusercontent.com/ggml-org/whisper.cpp/master/samples/jfk.wav'],'max_chars':4000,'recovery':'manual','fresh':True}))
 assert audio['quality']=='ok' and 'country' in audio['content'].lower() and audio['extraction']['segments']
 browser=value(tool(public,'public-browser-checkpoint','drive',{'url':'https://docs.python.org/3/library/sqlite3.html','session':'upgrade-public-smoke','steps':[{'action':'snapshot','limit':3},{'action':'checkpoint'}],'screenshot':'never'}))
 assert browser['ok']
 research=value(tool(public,'public-research-coverage','research',{'question':'Python sqlite3 in memory database','max_sources':2,'max_chars':1000,'profile':'web'}))
 assert research['coverage']['facets'] and not research['coverage']['answer_verified']
 closed=value(tool(public,'public-browser-close','drive',{'session':'upgrade-public-smoke','close_session':True,'screenshot':'never'}))
 assert closed['session']['closed']
(ROOT/'public-checks.json').write_text(json.dumps({'version':caps['version'],'tools':len(names),'all_assertions_passed':True,'checks':['workflow hash','new tool schemas','scoped quote selectors','MCP-to-REST evidence continuity','site coverage ledger','fresh discovery','local speech through public MCP','public browser checkpoint and cleanup']},indent=2))
print('PASS: all public production assertions')
