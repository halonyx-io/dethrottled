# Evaluation-only policy exception for the exact private fixture. Never deploy.
from urllib.parse import urlsplit
import server
original = server._public_url
server._public_url = lambda url: (urlsplit(url).hostname == 'dethrottled-dependable-fixture' and urlsplit(url).port == 19890) or original(url)
app = server.app
original_host = server._public_hostname
server._public_hostname = lambda host: host == 'dethrottled-dependable-fixture' or original_host(host)
