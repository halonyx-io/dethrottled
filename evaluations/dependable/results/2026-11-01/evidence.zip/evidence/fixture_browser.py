# Evaluation-only policy exception for the exact private fixture. Never deploy.
from urllib.parse import urlsplit
import service
original = service._public_network_target
async def allowed(url):
    return (urlsplit(url).hostname == 'dethrottled-dependable-fixture' and urlsplit(url).port == 19890) or await original(url)
service._public_network_target = allowed
app = service.app
