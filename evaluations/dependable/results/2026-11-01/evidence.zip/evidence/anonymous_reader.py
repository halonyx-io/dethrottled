import concurrent.futures,json,time,urllib.request,urllib.error
from pathlib import Path
root=Path(__file__).parent
manifest=json.loads((root/'web-manifest.json').read_text())['read'][:8]
(root/'anonymous-reader-manifest.json').write_text(json.dumps({'provider':'Jina Reader','authentication':'none','cases':manifest,'limit':'Anonymous availability and phrase presence only, no paid account or search comparison'},indent=2))
def run(case):
 name,url,expected=case;start=time.monotonic()
 request=urllib.request.Request('https://r.jina.ai/'+url,headers={'User-Agent':'dethrottled-comparative-reader-audit/1.0','Accept':'text/plain'})
 try:
  with urllib.request.urlopen(request,timeout=60) as response:status=response.status;text=response.read(2000000).decode('utf-8','replace')[:120000]
  result={'status':status,'pass':all(v.lower() in text.lower() for v in expected),'content':text}
 except urllib.error.HTTPError as error:result={'status':error.code,'pass':False,'error':error.read(500).decode('utf-8','replace')}
 except Exception as error:result={'pass':False,'error':type(error).__name__+': '+str(error)[:200]}
 return {'case':name,'source':url,'elapsed_ms':round((time.monotonic()-start)*1000),**result}
rows=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for row in pool.map(run,manifest):
  rows.append(row);(root/'anonymous-reader.json').write_text(json.dumps(rows,indent=2));print(row['case'],row.get('status'),row['pass'],flush=True)
