Raw run evidence for REPORT.md. summary.json contains scored totals.
web-startup-invalid.json and browser-benchmark-first.json record excluded harness failures; final scored browser results are browser-benchmark.json.
Paid provider calls were mocked only; anonymous-reader.json records the separate unauthenticated Jina probe.
Model thinking fields and credentials are not included.
