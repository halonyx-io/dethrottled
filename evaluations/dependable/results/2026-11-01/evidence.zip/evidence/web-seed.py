"""Small live-web coverage check, with preregistered domains/phrases and raw replies.

This is acquisition/discovery evidence, not a paid-provider or answer-accuracy benchmark.
"""
import concurrent.futures
import json
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = Path('/home/adminion/Documents/Codex/2026-10-31/hi/work/dethrottled-dependable')
SEARCH = [
    ('python-sqlite', 'Python sqlite3 official documentation', 'python.org'),
    ('sqlite-wal', 'SQLite WAL checkpoint official documentation', 'sqlite.org'),
    ('mdn-indexeddb', 'IndexedDB API MDN', 'mozilla.org'),
    ('docling-layout', 'Docling table structure PDF documentation', 'docling-project.github.io'),
    ('crossref-api', 'Crossref REST API documentation', 'crossref.org'),
    ('w3c-provenance', 'W3C PROV overview recommendation', 'w3.org'),
    ('french-python', 'documentation Python sqlite3 français', 'python.org'),
    ('german-python', 'Python Dokumentation sqlite3 deutsch', 'python.org'),
]
READ = [
    ('python-doc', 'https://docs.python.org/3/library/sqlite3.html', ['sqlite3', 'Connection']),
    ('sqlite-wal-doc', 'https://www.sqlite.org/wal.html', ['checkpoint', 'WAL']),
    ('mdn-doc', 'https://developer.mozilla.org/en-US/docs/Web/API/IndexedDB_API', ['IndexedDB']),
    ('docling-doc', 'https://docling-project.github.io/docling/', ['Docling']),
    ('w3c-doc', 'https://www.w3.org/TR/prov-overview/', ['PROV']),
    ('ietf-text', 'https://www.rfc-editor.org/rfc/rfc9110.txt', ['HTTP Semantics']),
    ('json-source', 'https://raw.githubusercontent.com/vega/vega-datasets/main/data/cars.json',
     ['Miles_per_Gallon', 'Horsepower']),
    ('csv-source', 'https://raw.githubusercontent.com/plotly/datasets/master/2014_usa_states.csv',
     ['Alabama', 'California']),
]
manifest = {'search': SEARCH, 'read': READ, 'order': ['baseline', 'candidate'],
            'limits': '8 queries and 8 sources, single run each, no semantic accuracy scoring; '
                      'same-host sequential builds are exposed to upstream time variation.'}
OUT.mkdir(exist_ok=True)
(OUT / 'web-manifest.json').write_text(json.dumps(manifest, indent=2))
records = []


def run(item):
    build, kind, case = item
    name, source, expected = case
    base = 'http://127.0.0.1:' + ('8787' if build == 'baseline' else '18392')
    path = '/v2/search' if kind == 'search' else '/fetch'
    payload = ({'query': source, 'limit': 8, 'fresh': True, 'profile': 'web'} if kind == 'search'
               else {'urls': [source], 'fresh': True, 'max_chars': 120000,
                     'recovery': 'manual', 'render': 'never'})
    request = urllib.request.Request(base + path, data=json.dumps(payload).encode(),
                                     headers={'Content-Type': 'application/json'})
    start = time.monotonic()
    try:
        with urllib.request.urlopen(request, timeout=150) as response:
            result = json.load(response)
        if kind == 'search':
            rows = result.get('results', [])
            passed = any(expected in row.get('url', '') for row in rows)
        else:
            passed = result[0].get('quality') == 'ok' and all(
                value.casefold() in result[0].get('content', '').casefold() for value in expected)
        row = {'pass': passed, 'result': result}
    except Exception as exc:
        row = {'pass': False, 'error': type(exc).__name__ + ': ' + str(exc)[:200]}
    return {'build': build, 'kind': kind, 'case': name, 'input': payload,
            'elapsed_ms': round((time.monotonic()-start)*1000), **row}


for build in ['baseline', 'candidate']:
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for result in pool.map(run, [(build, 'search', c) for c in SEARCH] +
                               [(build, 'read', c) for c in READ]):
            records.append(result)
            (OUT / 'web-results.json').write_text(json.dumps(records, indent=2))
            print(build, result['kind'], result['case'], result['pass'], flush=True)
print({b: {k: sum(r['pass'] for r in records if r['build'] == b and r['kind'] == k)
           for k in ['search', 'read']} for b in ['baseline', 'candidate']})
