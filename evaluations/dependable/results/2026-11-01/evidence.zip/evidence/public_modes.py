from pathlib import Path
import json,time,uuid
import httpx
root=Path(__file__).parent
headers={'Authorization':'Bearer '+(root/'live-token').read_text().strip(),'User-Agent':'dethrottled-document-mode-sdk-audit/1','Accept':'application/json, text/event-stream'}
rows=[]
def value(result):
 if result.get('isError'):raise AssertionError(result)
 data=result.get('structuredContent')
 if data is None:data=json.loads(result['content'][0]['text'])
 if isinstance(data,dict) and 'result' in data:data=data['result']
 return data[0] if isinstance(data,list) else data
with httpx.Client(trust_env=False,timeout=240) as client:
 start=time.monotonic();args={'urls':['https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf'],'document_mode':'layout','fresh':True,'recovery':'manual','max_chars':2000}
 response=client.post('https://api.halonyx.io/mcp',headers=headers,json={'jsonrpc':'2.0','id':uuid.uuid4().hex,'method':'tools/call','params':{'name':'fetch','arguments':args}});response.raise_for_status();result=response.json();row=value(result['result']);rows.append({'case':'public-explicit-layout','elapsed_ms':round((time.monotonic()-start)*1000),'result':result});assert row['quality']=='ok' and row['extraction'].get('parser')=='docling',row
 response=client.post('https://api.halonyx.io/documents/read',headers=headers,json={'document_id':row['document_id'],'document_mode':'native','reparse':True,'max_chars':2000});response.raise_for_status();native=response.json();rows.append({'case':'public-rest-native-reparse','result':native});assert native.get('quality')=='ok' and native['extraction'].get('parser')!='docling'
(root/'public-document-modes.json').write_text(json.dumps(rows,indent=2));print('PASS: public MCP Docling fetch and REST native reparse of identical retained PDF bytes')
