from pathlib import Path
import subprocess,json,hashlib
root=Path(__file__).parent;repo=Path('/home/adminion/dethrottled')
def out(args):return subprocess.check_output(args,text=True).strip()
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
api_code="import hashlib,json;from dethrottled import server,jobs,formats,workflow,access,site,structure,timed,media,layout,providers,fetch,search,research;print(json.dumps({m.__name__:hashlib.sha256(open(m.__file__,'rb').read()).hexdigest() for m in [server,jobs,formats,workflow,access,site,structure,timed,media,layout,providers,fetch,search,research]}))"
api=json.loads(out(['docker','exec','dethrottled-dethrottled-1','python','-c',api_code]))
for name,h in api.items():assert h==digest(repo/'src'/Path(*name.split('.')).with_suffix('.py')),name
code="import hashlib;print(hashlib.sha256(open('/app/service.py','rb').read()).hexdigest())"
for container,source in [('dethrottled-browser-search-1','browser-search/service.py'),('dethrottled-media-worker-1','media-worker/service.py'),('dethrottled-docling-worker-1','docling-worker/service.py')]:
 assert out(['docker','exec',container,'python','-c',code])==digest(repo/source),container
assert digest(repo/'src/dethrottled/access.py')==digest('/opt/dethrottled-access/dethrottled_access.py')
assert digest(repo/'adapters/mcp_server.py')==digest('/opt/dethrottled-mcp/server.py')
assert digest(repo/'adapters/rest_gateway.py')==digest('/opt/halonyx-api-gateway/public_gateway.py')
backup=Path((root/'backup-location.txt').read_text().strip())
assert digest(backup/'tokens.json')==digest('/etc/dethrottled-access/tokens.json')
def env(path):return dict(line.split('=',1) for line in path.read_text().splitlines() if '=' in line and not line.startswith('#'))
a,b=env(backup/'.env'),env(repo/'.env')
different=sorted(k for k in a.keys()|b.keys() if a.get(k)!=b.get(k))
assert different==['DETHROTTLED_LAYOUT_WORKER_URL'],different
names=['dethrottled-dethrottled-1','dethrottled-browser-search-1','dethrottled-media-worker-1']
images={n:out(['docker','inspect',n,'--format','{{.Image}}']) for n in names}
value={'version':'0.7.0','runtime_source_matches_checkout':True,'api_module_sha256':api,'images':images,'registry_unchanged':True,'environment_changed_fields':different,'baseline_commit':out(['git','-C',str(repo),'rev-parse','HEAD']),'tests':'524 passed;15 skipped;2 network tests deselected','fixture_exceptions_deployed':False,'mcp_rest_adapters':'existing systemd services; source hashes match checkout'}
(root/'provenance.json').write_text(json.dumps(value,indent=2));print('PASS: deployed sources match checkout; token registry unchanged; only declared environment field changed')
