from pathlib import Path
import datetime, hashlib, json, shutil, sqlite3, subprocess
root=Path(__file__).parent
repo=Path('/home/adminion/dethrottled')
assert '523 passed' in (root/'regression-final.txt').read_text()
assert 'All checks passed' in (root/'lint-final.txt').read_text()
browser=json.loads((root/'browser-benchmark.json').read_text())
assert sum(bool(r.get('pass')) for r in browser if r['build']=='candidate')==8
web=json.loads((root/'web-results.json').read_text())
assert sum(r['pass'] for r in web if r['build']=='candidate')==16
assert all(r['pass'] for r in json.loads((root/'components-0.7.0.json').read_text()))
cold=json.loads((root/'cold-actions/interactive_actions.json').read_text())
assert not cold['error'] and all(t in cold['answer'] for t in ['updated 291','420','tonnes'])
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S')
backup=Path('/var/backups/dethrottled')/(stamp+'-dependable')
backup.mkdir(parents=True, mode=0o700)
for source,name in [('/opt/dethrottled-mcp/server.py','mcp.py'),('/opt/halonyx-api-gateway/public_gateway.py','rest.py'),('/etc/dethrottled-access/tokens.json','tokens.json'),(str(repo/'.env'),'.env')]:
 shutil.copy2(source,backup/name);(backup/name).chmod(0o600)
for name in ['docker-compose.yml','docker-compose.agents.yml']:
 (backup/name).write_bytes(subprocess.check_output(['git','-C',str(repo),'show','HEAD:'+name]))
for file in Path('/var/lib/docker/volumes/dethrottled_dethrottled-data/_data').glob('*.sqlite'):
 with sqlite3.connect(f'file:{file}?mode=ro',uri=True) as src,sqlite3.connect(backup/file.name) as dst:src.backup(dst)
registry=Path('/etc/dethrottled-access/tokens.json')
registry_hash=hashlib.sha256(registry.read_bytes()).hexdigest()
rollback={}
def run(*args):subprocess.run(args,check=True,cwd=repo)
for name in ['dethrottled','dethrottled-browser-search']:
 target=name+':pre-dependable-'+stamp;run('docker','tag',name+':local',target);rollback[name]=target
 run('docker','tag',name+':dependable-candidate',name+':local')
run('docker','tag','dethrottled-docling:candidate','dethrottled-docling:local')
p=repo/'.env';lines=[line for line in p.read_text().splitlines() if not line.startswith('DETHROTTLED_LAYOUT_WORKER_URL=')];lines.append('DETHROTTLED_LAYOUT_WORKER_URL=http://docling-worker:19891');p.write_text('\n'.join(lines)+'\n');p.chmod(0o600)
run('docker','compose','-f','docker-compose.yml','-f','docker-compose.agents.yml','--profile','media','--profile','layout','up','-d','--no-build','--no-deps','browser-search','docling-worker','dethrottled')
run('install','-o','root','-g','root','-m','0644',str(repo/'adapters/mcp_server.py'),'/opt/dethrottled-mcp/server.py')
run('systemctl','restart','dethrottled-mcp')
assert hashlib.sha256(registry.read_bytes()).hexdigest()==registry_hash
(root/'backup-location.txt').write_text(str(backup)+'\n')
(root/'deployment.json').write_text(json.dumps({'version':'0.7.0','backup':str(backup),'rollback_images':rollback,'registry_unchanged':True,'environment_changed_fields':['DETHROTTLED_LAYOUT_WORKER_URL'],'fixture_exceptions_deployed':False},indent=2))
print('Deployed 0.7.0 with protected backup; token registry unchanged.')
