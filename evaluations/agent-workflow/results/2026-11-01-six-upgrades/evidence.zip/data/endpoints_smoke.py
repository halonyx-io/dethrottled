from pathlib import Path
import urllib.request,json,time
root=Path(__file__).parent;rows=[]
def call(label,path,body):
 t=time.perf_counter();r=urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:18392'+path,data=json.dumps(body).encode(),headers={'Content-Type':'application/json'}),timeout=600)
 result=json.load(r);rows.append({'label':label,'path':path,'input':body,'wall_s':round(time.perf_counter()-t,3),'result':result});(root/'endpoints-smoke.json').write_text(json.dumps(rows,indent=2));return result
for _ in range(30):
 try:
  with urllib.request.urlopen('http://127.0.0.1:18392/health',timeout=2) as r:
   if r.status==200:break
 except Exception:time.sleep(1)
base='http://dethrottled-upgrade-fixture:19890'
r=call('site-three-sources','/site/crawl',{'urls':[base+'/site/'],'max_pages':5,'render':'never'})
assert r['coverage']['succeeded']==3 and r['coverage']['frontier_exhausted'],r
r=call('timed-captions','/fetch',{'urls':[base+'/captions.vtt'],'recovery':'manual'})[0]
assert '7341' in r['content'] and r['extraction']['segments'][0]['start_seconds']==5,r
s=call('caption-quote-selectors','/documents/structure',{'document_id':r['document_id']})
assert s['blocks'][0]['citation']['time_selector']['end_seconds']==7.5,s
r=call('actual-audio-through-fetch','/fetch',{'urls':[base+'/sample.wav'],'recovery':'manual','max_chars':4000})[0]
assert r['quality']=='ok' and r['extraction']['method']=='speech_recognition',r
assert 'country' in r['content'].lower() and r['extraction']['segments'],r
r=call('browser-response-retention','/drive',{'session':'api-network','url':base+'/login','allowed_hosts':['dethrottled-upgrade-fixture'],'screenshot':'never','steps':[{'action':'click','selector':'#login'},{'action':'wait_for','selector':'#ready','ms':10000},{'action':'network','name':'body','value':'/data'}]})
assert r['ok'],r
data=r['steps'][-1]['data'];assert data.get('document_id'),r
r=call('reopen-browser-response','/documents/read',{'document_id':data['document_id']})
assert json.loads(r['content'])['secret']==7341,r
call('close-browser-test','/drive',{'session':'api-network','close_session':True})
print('PASS: site coverage, timed captions, time citations, actual audio via fetch and retained browser response')
