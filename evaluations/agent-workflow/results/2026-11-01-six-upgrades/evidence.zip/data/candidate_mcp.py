from urllib.parse import urlsplit
import server
original=server._public_url
def fixture(url):
 p=urlsplit(url)
 return p.scheme=='http' and p.hostname=='dethrottled-upgrade-fixture' and p.port==19890
server._public_url=lambda url:fixture(url) or original(url)
app=server.app
