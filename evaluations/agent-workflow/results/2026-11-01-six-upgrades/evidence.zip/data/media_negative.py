from pathlib import Path
import urllib.request,urllib.error,json,io,wave
root=Path(__file__).parent;cases=[]
buf=io.BytesIO()
with wave.open(buf,'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(16000);w.writeframes(b'\0'*(16000*2*3))
for label,data in [('silence',buf.getvalue()),('invalid',b'not an audio stream'),('no_audio_video',(root/'no-audio.mp4').read_bytes())]:
 req=urllib.request.Request('http://127.0.0.1:18391/transcribe',data=data)
 try:
  with urllib.request.urlopen(req,timeout=60) as r:status=r.status;result=json.load(r)
 except urllib.error.HTTPError as e:status=e.code;result=json.load(e)
 cases.append({'label':label,'status':status,'result':result})
(root/'media-negative.json').write_text(json.dumps(cases,indent=2))
assert cases[0]['status']==200 and cases[0]['result']['segments']==[],cases
assert cases[1]['status']==422,cases
assert cases[2]['status']==422 and 'no_audio_stream' in str(cases[2]['result']),cases
print('PASS: silence produces no invented transcript; invalid input rejected')
