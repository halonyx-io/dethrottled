from pathlib import Path
import json,time,urllib.request,urllib.error,subprocess,uuid
root=Path(__file__).parent;rows=[]
def call(label,payload):
 start=time.perf_counter(); req=urllib.request.Request('http://127.0.0.1:18390/drive',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(req,timeout=80) as r:status=r.status;data=json.load(r)
 except urllib.error.HTTPError as e:status=e.code;data=json.load(e)
 rows.append({'label':label,'input':payload,'status':status,'wall_ms':round((time.perf_counter()-start)*1000,2),'result':data})
 (root/'browser-smoke.json').write_text(json.dumps(rows,indent=2))
 return data,status
def ready():
 for _ in range(45):
  try:
   with urllib.request.urlopen('http://127.0.0.1:18390/health',timeout=2) as r:
    if r.status==200:return
  except Exception:time.sleep(1)
 raise RuntimeError('browser not ready')
ready()
session='restart-check-'+uuid.uuid4().hex[:8]
base={'session':session,'allowed_hosts':['dethrottled-upgrade-fixture'],'screenshot':'never'}
login={**base,'url':'http://dethrottled-upgrade-fixture:19890/login','operation_id':'login-once','steps':[{'action':'click','selector':'#login'},{'action':'wait_for','selector':'#ready','ms':10000},{'action':'network'},{'action':'network','name':'body','value':'/data'},{'action':'checkpoint'}]}
result,status=call('login-network-checkpoint',login)
assert status==200 and result['ok'],result
body=next(s['data'] for s in result['steps'] if s['action']=='network' and isinstance(s.get('data'),dict) and 'content' in s['data'])
assert json.loads(body['content'])=={'secret':7341,'authenticated':True},body
result,status=call('stable-network-response-id',{**base,'steps':[{'action':'network','name':'body','selector':body['response_id']}]})
assert status==200 and result['ok'] and result['steps'][0]['data']['content']==body['content'],result
code="""import service,hashlib,json,time
b=service.DriveRequest(session='SESSION_PLACEHOLDER',allowed_hosts=['dethrottled-upgrade-fixture'],screenshot='never',operation_id='unknown',steps=[{'action':'click','selector':'#login'}])
f=hashlib.sha256(json.dumps(b.model_dump(exclude={'operation_id'}),sort_keys=True).encode()).hexdigest()
service._persist_operation((b.session,b.operation_id),{'fingerprint':f,'state':'running','created':time.time()})
"""
code=code.replace('SESSION_PLACEHOLDER',session)
subprocess.run(['sudo','-n','docker','exec','dethrottled-upgrade-browser','python','-c',code],check=True)
subprocess.run(['sudo','-n','docker','restart','dethrottled-upgrade-browser'],check=True,stdout=subprocess.DEVNULL)
ready()
result,status=call('restart-restore',{**base,'allowed_hosts':[],'steps':[{'action':'wait_for','selector':'#ready','ms':10000},{'action':'text','selector':'#state'},{'action':'network','name':'body','value':'/data'}]})
assert status==200 and result['ok'] and result['session']['restored_from_checkpoint'],result
assert result['steps'][1]['data']=='kept',result
assert json.loads(result['steps'][2]['data']['content'])['authenticated'],result
result,status=call('completed-operation-replay',login)
assert result['operation_replayed'] and status==200,result
result,status=call('unknown-operation-blocked',{**base,'operation_id':'unknown','steps':[{'action':'click','selector':'#login'}]})
assert status==409 and 'outcome_unknown' in str(result),result
result,status=call('close-and-delete-checkpoint',{**base,'close_session':True})
assert result['session']['closed'],result
result,status=call('closed-checkpoint-cannot-restore',{**base,'steps':[{'action':'text'}]})
assert status==409,result
print('PASS: real Chromium login, XHR body, checkpoint, process restart, cookies/localStorage restoration, durable replay, unknown-outcome fence, checkpoint deletion')
