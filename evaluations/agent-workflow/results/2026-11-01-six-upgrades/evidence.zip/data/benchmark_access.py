from pathlib import Path
import importlib.util,json,time,statistics
root=Path(__file__).parent
backup=root
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
old=load('old_access',backup/'baseline_access.py');new=load('new_access',root/'candidate_access.py')
gates={'baseline':old.Admission(root/'old-admission.sqlite'),'candidate':new.Admission(root/'new-admission.sqlite')}
rows=[]
for i in range(12):
 for name in (['baseline','candidate'] if i%2 else ['candidate','baseline']):
  t=time.perf_counter();gate=gates[name];gate.release(gate.acquire('benchmark'))
  rows.append({'arm':name,'pair':i,'wall_ms':round((time.perf_counter()-t)*1000,3)})
summary={name:{'median_ms':statistics.median(r['wall_ms'] for r in rows if r['arm']==name),'max_ms':max(r['wall_ms'] for r in rows if r['arm']==name)} for name in gates}
(root/'admission-benchmark.json').write_text(json.dumps({'records':rows,'summary':summary,'scope':'Same-host sequential acquire+release, alternating arms; not an end-to-end latency percentile benchmark'},indent=2));print(summary)
