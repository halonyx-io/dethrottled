import json
from http.server import BaseHTTPRequestHandler,HTTPServer
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  content_type='text/html';status=200;cookie=False
  if self.path=='/login':
   data=b'''<button id="login" onclick="localStorage.setItem('saved','kept');fetch('/auth').then(()=>location='/app')">Log in</button>'''
  elif self.path=='/auth':data=b'ok';cookie=True
  elif self.path=='/app':
   data=b'''<h1>Private report</h1><div id="state"></div><script>document.querySelector('#state').textContent=localStorage.getItem('saved')||'missing';fetch('/data').then(r=>r.json()).then(x=>{document.body.insertAdjacentHTML('beforeend','<div id="ready">ready</div>')})</script>'''
  elif self.path=='/data':
   content_type='application/json';status=200 if 'ticket=gold' in self.headers.get('Cookie','') else 401
   data=json.dumps({'secret':7341 if status==200 else None,'authenticated':status==200}).encode()
  elif self.path=='/site/':data=b'<h1>Reports</h1><a href="/site/a">first</a><a href="/site/b">second</a>'
  elif self.path=='/site/a':data=b'<h1>First source</h1><p>ALPHA allocation is 7341 crates.</p><a href="/site/">back</a>'
  elif self.path=='/site/b':data=b'<h1>Second source</h1><p>BETA allocation is 291 tonnes.</p>'
  elif self.path=='/sample.wav':
   from pathlib import Path
   content_type='audio/wav';data=Path('/tmp/jfk.wav').read_bytes()
  elif self.path=='/captions.vtt':
   content_type='text/vtt';data=b'WEBVTT\n\n00:05.000 --> 00:07.500\nThe shipment is 7341 crates.\n'
  else:status=404;data=b'missing'
  self.send_response(status);self.send_header('Content-Type',content_type);self.send_header('Content-Length',str(len(data)))
  if cookie:self.send_header('Set-Cookie','ticket=gold; HttpOnly; Path=/')
  self.end_headers();self.wfile.write(data)
 def log_message(self,*a):pass
HTTPServer(('0.0.0.0',19890),Handler).serve_forever()
