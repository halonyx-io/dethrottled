from pathlib import Path
import urllib.request,json,time,hashlib
root=Path(__file__).parent
url='https://raw.githubusercontent.com/ggml-org/whisper.cpp/master/samples/jfk.wav'
with urllib.request.urlopen(url,timeout=60) as r:data=r.read(5_000_000)
(root/'jfk.wav').write_bytes(data)
start=time.perf_counter()
req=urllib.request.Request('http://127.0.0.1:18391/transcribe',data=data,headers={'Content-Type':'application/octet-stream'})
with urllib.request.urlopen(req,timeout=600) as r:result=json.load(r)
record={'source':url,'source_sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'wall_s':round(time.perf_counter()-start,3),'result':result}
(root/'media-smoke.json').write_text(json.dumps(record,indent=2))
text=' '.join(s['text'] for s in result['segments'])
assert 'country' in text.lower() and 'ask' in text.lower(),text
assert all(s['end_seconds']>=s['start_seconds']>=0 for s in result['segments'])
print('PASS: actual speech recognised with timed segments:',text)
