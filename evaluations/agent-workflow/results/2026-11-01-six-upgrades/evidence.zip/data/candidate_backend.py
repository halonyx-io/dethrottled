from urllib.parse import urlsplit
from dethrottled import research, server
original=research.public_url
def fixture(url):
 p=urlsplit(url)
 return p.scheme=='http' and p.hostname=='dethrottled-upgrade-fixture' and p.port==19890
research.public_url=lambda url:fixture(url) or original(url)
server.index_fetched=lambda *a,**k:0
app=server.app
