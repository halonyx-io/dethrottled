"""Isolated benchmark only: admit one fixture server; never deploy this wrapper."""
from urllib.parse import urlsplit
from dethrottled import research, server
FIXTURE_HOST='172.17.0.1'
def fixture(url):
 p=urlsplit(url);return p.scheme=='http' and p.hostname==FIXTURE_HOST and p.port==18901
original=research.public_url
research.public_url=lambda url: fixture(url) or original(url)
server.index_fetched=lambda *a,**k: 0
original_drive=server.fs.browser_drive
def drive(payload):
 if payload.get('url') and not fixture(payload['url']):
  raise ValueError('Evaluation drive is restricted to the fixture server')
 return original_drive(dict(payload,public_only=False))
server.fs.browser_drive=drive
app=server.app
