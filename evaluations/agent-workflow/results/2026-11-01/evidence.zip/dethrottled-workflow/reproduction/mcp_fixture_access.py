"""Isolated benchmark only: preserve real MCP schemas/policy, admit one fixture host."""
from urllib.parse import urlsplit
import mcp_server as service
original=service._public_url
def fixture(url):
 p=urlsplit(url);return p.scheme=='http' and p.hostname=='172.17.0.1' and p.port==18901
service._public_url=lambda url: fixture(url) or original(url)
original_hostname=service._public_hostname
service._public_hostname=lambda host:host=='172.17.0.1' or original_hostname(host)
app=service.app
