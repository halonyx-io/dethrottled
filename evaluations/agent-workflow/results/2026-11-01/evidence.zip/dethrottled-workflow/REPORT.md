# Dethrottled 0.5.0: can an uncoached agent use the capabilities?

1 November 2026. Implemented, tested and deployed on szbox. Evidence includes **44 fresh model conversations**, their tool calls/results, final answers, model metadata, source fixtures, images and failed attempts. Credentials and provider private-reasoning fields are excluded.

## What the results establish

The service now presents an agent workflow rather than just a capability inventory. In the main controlled test, an agent received only the task, the server's actual published MCP instructions, and its tool descriptions/schemas. It received no Dethrottled examples, coaching, source-layout hints or answer keys.

| Evaluation | Baseline 0.4.0 | Candidate 0.5.0 |
| --- | ---: | ---: |
| Main confirmation: reviewed required-answer completion, 16 model turns allowed | 14/16 | 16/16 |
| Larger-budget retests: two difficult families, 32 model turns allowed | 4/4 | 4/4 |
| Main confirmation: unmodified mechanical score | 9/16 | 12/16 |
| Main confirmation: tool calls across all 16 tasks | 102 | 62 |
| Main confirmation: median elapsed time | 8.31 s | 9.39 s |

**The baseline was already capable, and more time allowed it to recover the difficult sources on fresh retests.** These results support better guidance and recovery in this small suite. They do not establish a general increase in eventual source coverage, a general accuracy gain, or that 0.4.0 could never recover those sources. The candidate was not faster by median elapsed time, and speed is not the acceptance criterion.

The two incomplete baseline confirmation runs were the second image-timetable and PDF-chart variants; they exhausted the fixed model-turn budget without a final answer. They were not wrong final answers. The larger-budget tests used fresh conversations, not continuations, so their differences also reflect model variability. Temperature zero did not make the runs deterministic. This is eight synthetic task families with two data variants, not 32 independent kinds of research problem and not a statistically established effect size.

The cases tested deep text, later spreadsheet/CSV rows, an image timetable, a browser-generated CSV, later PDF pages, an absent answer, an untrusted source instruction, and a PDF chart needing pixel inspection. Both versions found deep-text and later-table/PDF evidence. In the candidate's confirmation runs, actual `view_document_image` calls delivered the chart pixels to the model; the rendered labels agreed with the answers. For example, the second chart visibly says **1514 crates**, and the model returned that quantity and unit.

See [per-family results](confirmation/case-results.md), [all automatic scores and answers](confirmation/summary.json), [individual review decisions](confirmation/manual-review.json), and [reviewed totals](confirmation/reviewed-summary.json).

## Why the mechanical scores differ

The frozen scorer was deliberately kept unchanged after the results arrived. It produced nine false negatives that are retained in the raw data:

- Both versions correctly said the certificate expiry was absent and distinguished the issue date. Four runs were mechanically rejected because they mentioned that issue date while explaining why it was not an expiry date.
- Both versions rejected the planted false stock quantity. Four runs were mechanically rejected because their caveats quoted the rejected number.
- One baseline run correctly decoded the CSV's base64 payload from the actual returned HTML, rather than capturing the browser export. The literal-number grounding check could not recognize encoded source evidence. That is a valid alternative endpoint workflow, and the agent disclosed its method; it is counted as a reviewed success.

The reviewed scores are **author-reviewed required-answer completion**, not blinded independent judgments. The review checks the requested fact/unit, source evidence, citations and the explicit visual requirement. It does not validate every incidental sentence. For instance, one candidate answer speculated that a table outlier was intentional; the fixture supports the unusual value but not its intent. Grounded core answers can still come with unnecessary inference.

## What changed

**1. Workflow at connection time.** MCP initialization publishes the preferred progression and its shortcuts: known URL → read directly; unknown source → discover; relevant retained evidence → reopen; incomplete source → select another range or strengthen acquisition; interaction/export → drive; uncertain chart/OCR → inspect pixels. It explains that `quality: ok` means extraction succeeded, not that an answer was found. Tool descriptions cross-reference the relevant follow-ups. REST capabilities publish the same policy.

A client must actually forward the published instructions and tool descriptions to its model. A client that drops them, hides returned workflow metadata, or cannot transmit native image blocks will not receive the full benefit. This benchmark supplied those normal MCP surfaces; it does not prove that every existing agent integration forwards them correctly.

**2. Actionable results.** Read results include `workflow.state`, explicit uncertainty about source completeness, and `next_actions` with a tool name, REST endpoint, concrete arguments and a reason. These cover retained-text continuation, later PDF/table windows, stronger rendered reads, relevant assets and visual inspection. Actions are suggestions to choose according to the question, not a compulsory list to execute. `answer_verified` remains false; Dethrottled does not invent a semantic correctness verdict.

**3. Bounded automatic recovery.** Default fetch behavior can retry navigation-only content with rendering and follow up to two relevant image/document assets from an image-content page. Attempts are visible in `recovery_attempts`; recovered assets identify their parent. `recovery: manual` preserves explicit acquisition control, and render/OCR choices remain effective. The service does not guess UI mutations or click arbitrary export controls on the agent's behalf.

Two pilot-driven repairs make those capabilities more usable:

- Browser host bounds can be derived from validated navigation URLs when omitted. Explicit lists still apply, and public/private target checks remain in force. Several pilot errors involved missing host lists or accidentally including a port in a hostname.
- Document reparsing and pixel inspection can reacquire missing HTTP source bytes on demand, through the existing bounded readers. The bytes must match the retained original file hash. Changed content returns 409; unavailable or unhashed content requires refetch/capture rather than silently substituting a different source version. Plain retained-text reads still need no origin request.

MCP drive screenshots also now use native image blocks, with structured metadata, instead of making a vision-capable agent discover base64 buried in text. REST/internal base64 fields remain compatible.

## Pilot, confirmation and limits of the comparison

The development pilot contains four conversations on the export/chart cases. It exposed a real candidate failure: the candidate chart run exhausted its turn budget while the baseline completed it. Those traces were used to improve browser setup and source-byte recovery. They remain in [the pilot records](pilot/summary.json).

After those repairs, executable candidate code, adapter contracts and the scoring protocol were frozen before the 32-run confirmation batch. Only documentation and separate review tooling changed during that batch. [The environment snapshot](confirmation/environment.json) records file hashes, runtime image IDs and the baseline commit (`df6278e`). The published contracts were identical between confirmation and the larger-budget retests. [The protocol](confirmation/protocol.json) records tasks, expected values, model, temperature, turn limit and common prompt.

Both arms used **`deepseek-v4.1-flash:cloud` through the already-configured local Ollama service** (Ollama 0.35.0 when packaged). No new API key was needed. Every task started a new conversation. Unique URLs prevented extraction-cache reuse across runs; corpus indexing was disabled in isolated test wrappers, and observed browser sessions were closed after each run. Arm order alternated to reduce a systematic time/order advantage. Tool calls emitted in one model turn were executed sequentially by the harness, identically for both arms. The shared host was not isolated from other workloads; timing is descriptive, not a performance benchmark.

The deterministic fixture server used a private Docker-bridge address and nonstandard port. Isolated wrappers admitted that exact fixture server through public-target checks; those wrappers were never deployed. The unusual host/port contributed to malformed host arguments in baseline attempts, so this environment can exaggerate a browser-setup problem compared with ordinary public URLs. Egress/host-policy checks were tested separately, and public production tests used real public URLs.

This comparison tests a bundle of workflow changes. It does not isolate the contribution of instructions, next-action metadata, automatic recovery, native images or on-demand source acquisition. It also does not test general web discovery/ranking, autonomous corpus reuse, choosing progressive jobs, real authenticated exports, multiple agent clients/models, noisy multilingual documents or universal file-format coverage. The two pilot task families were reused in confirmation; this is not an unseen-task holdout benchmark.

## Validation and deployment

- **495 regression tests passed**, 15 skipped, two network-marked tests excluded. Ruff and diff checks passed.
- Separate adapter checks cover inferred hosts, explicit host restrictions, private-target rejection and native MCP screenshot blocks.
- Eight final public production checks passed: workflow capabilities, exact policy agreement with the cold-tested MCP policy, read-result guidance, hash-verified source reacquisition, native MCP screenshots with inferred hosts, REST inferred hosts, unchanged registry and unchanged environment.
- Production smoke testing found an existing REST deployment problem: its systemd deny-by-default egress policy also blocked the configured DNS resolvers. Valid public URLs were consequently rejected during hostname validation. The fix permits those two configured resolvers while preserving the remaining egress restrictions. The initial 400 response and a subsequent restart-race 502 are preserved alongside the successful retest, rather than hidden.
- An attempted larger-budget test initially found the temporary baseline adapter had stopped. It was restarted unchanged before any model conversation in that batch; the startup error log is retained. The completed main confirmation had no provider/transport failures; its two errors are declared turn-budget exhaustion.

The tested API image and adapters are deployed as **0.5.0**. Existing browser/DDG, SearXNG, renderer, ranking configuration, credentials, environment and production data volume are preserved. A protected pre-upgrade backup is at `/var/backups/dethrottled/20261031-165600-workflow`, and the previous API image remains `dethrottled:workflow-base-20261031`. The DNS drop-in has an absent/original-state backup for rollback. Temporary test services, synthetic credentials and production smoke records were removed after verification.

## Evidence and the next useful test

The bundle preserves all **44 conversations**: four pilot, 32 confirmation and eight larger-budget retests. It contains visible prompts, published contracts, tool arguments/results, final answers, errors, timings, model usage metadata, image artifacts, generated source files and hashes, the source-request log, test logs and reproduction scripts. Provider private reasoning and credentials are not recorded. JSON references image artifacts by hash; raw text-only screenshot payloads may also appear in original tool-result text.

This is suitable as a narrowly described GitHub evidence set: **“A fresh agent used the guided reading workflow successfully on these declared synthetic tasks, with the baseline and larger-budget results disclosed.”** It is not evidence for “100% accurate agents,” “reads every source,” or a universal superiority claim. No GitHub publication was performed.

The next most useful validation is the user's actual agent integration, checking whether it forwards initialization policy, preserves tool descriptions/results and renders native images. Then repeat on several model families and a preregistered real-world source set. The evaluation scorer should parse the final answer field and distinguish rejected source instructions from adopted claims; its original version and scores should remain part of the record.

The native tool loop follows [Ollama's tool-calling documentation](https://docs.ollama.com/capabilities/tool-calling); cloud operation was checked against [Ollama's cloud documentation](https://docs.ollama.com/cloud).
