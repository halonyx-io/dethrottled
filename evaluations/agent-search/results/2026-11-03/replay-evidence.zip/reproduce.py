import hashlib,json,statistics
from pathlib import Path
from replay import evaluate,lists,menu_for,metrics
R=Path(__file__).parent
lock=json.loads((R/'selection-lock.json').read_text())
for name in ['questions','protocol']:
 assert hashlib.sha256((R/(name+'.json')).read_bytes()).hexdigest()==lock[name+'_sha256']
for broader,name in [(False,'normal'),(True,'broader')]:
 results,_,_=evaluate('development',broader)
 selected=next(r for r in results if r['config']==lock['selected'][name]['config'])
 for key,value in lock['selected'][name]['metrics'].items():
  assert abs(selected['metrics'][key]-value)<1e-9,(name,key)
expected=json.loads((R/'heldout-results.json').read_text())
for name,c in expected['configs'].items():
 rows=[]
 for q in json.loads((R/'questions.json').read_text()):
  if q['split']!='heldout':continue
  source=lists(json.loads((R/'captures'/(q['id']+'.json')).read_text()));ann={r['key']:r for r in json.loads((R/'labels'/(q['id']+'.json')).read_text())['labels']}
  menu,_=menu_for(q,source,c,name=='locked_broader');rows.append(metrics(menu,q,ann))
 for key,value in expected['aggregate'][name].items():
  if key=='backup_http_requests':continue
  assert abs(statistics.mean(r[key] for r in rows)-value)<1e-9,(name,key)
print('Frozen development and held-out metrics reproduced; no model or upstream calls.')
