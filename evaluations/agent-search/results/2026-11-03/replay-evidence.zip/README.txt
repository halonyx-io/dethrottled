Frozen agent-source-menu study, 3 November2026 (local date).
Unzip into a temporary directory. From a dethrottled checkout, run:
  DETHROTTLED_REPO_ROOT="$PWD" python3 /path/to/extracted/reproduce.py
Python3.10+ standard library only. No upstream requests, model, key or install needed.
Reproduce checks input hashes and selected-development/fixed-heldout metrics.
replay.py contains the full ranking/selection grid. Run only reproduce.py to avoid
rewriting the original selection lock. The heldout was not used to tune weights.
Candidate lists retain provider rank; DDG variants are one family.
Raw counters with incomplete hash correlation remain in captures; use normalized
telemetry counts for actual observed requests.
Fetched full page bodies, browser state, credentials and disposable secrets are
excluded. read-summary.json preserves per-query quality and verified facet counts;
retained page hashes and full content-verification records remain in the private raw
bundle. Public ranking replay is reproducible; exact live fetch content is not.
Dataset attribution: HotpotQA (Yang et al.), https://hotpotqa.github.io/ ; accessed
through hotpotqa/hotpot_qa on HuggingFace; CC-BY-SA4.0,
https://creativecommons.org/licenses/by-sa/4.0/ . Eighty question/reference/evidence
records retain their original text; remaining forty are curated task labels.
Search titles/snippets are captured observations from their respective sources;
no ownership of source content is claimed. Study code is MIT, like dethrottled.
Administrative capture repairs and invalid browser-control probes are retained,
explicitly excluded from relevance selections or counted as provider failures.
