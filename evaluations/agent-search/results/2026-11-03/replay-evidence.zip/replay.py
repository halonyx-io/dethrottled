import collections,hashlib,itertools,json,math,re,statistics,time,urllib.parse
from pathlib import Path
from labels import lists,canonical
ROOT=Path(__file__).parent
VERIFIED=json.loads((ROOT/'telemetry-normalized.json').read_text())
STOP=set('a an the of in on at by to and or is are was were do does did how what when where why which who can with for from as it its that this be not same have has two difference between'.split())
def tokens(text):return {w for w in re.findall(r'[^\W_]+',text.casefold()) if len(w)>2 and w not in STOP}
def suspect(q,primary):
 terms=tokens(q['question']);rows=primary[:5]
 if len(rows)<3:return True
 overlaps=[len(terms & tokens(r['title']+' '+r['snippet']))/max(1,len(terms)) for r in rows]
 return statistics.median(overlaps)<.10 or sum(x>0 for x in overlaps)<2
_GOLD={}
_METRICS={}
def goldfacets(row,q):
 cachekey=(q['id'],row['key'])
 if cachekey in _GOLD:return _GOLD[cachekey]
 key=canonical(urllib.parse.unquote(row['url']).replace('_',' ')).casefold();out=[]
 for i,ref in enumerate(q['references']):
  wanted=canonical(urllib.parse.unquote(ref['url']).replace('_',' ')).casefold()
  if key==wanted:out.append(i if q['source'].startswith('Hotpot') else 0)
 _GOLD[cachekey]=out
 return out
def metrics(menu,q,annotations):
 cachekey=(q['id'],tuple(r['key'] for r in menu))
 if cachekey in _METRICS:return dict(_METRICS[cachekey])
 grades=[];facets=set();high=[];off=[];gold=set();unknown=[]
 for r in menu:
  a=annotations.get(r['key'],{});g=goldfacets(r,q);good=bool(g) or a.get('grade',0)>=2;hc=bool(g) or good and a.get('confidence',0)>=.8
  grades.append(good);high.append(hc);off.append(not g and a.get('grade')==0 and a.get('confidence',0)>=.8);unknown.append(not g and a.get('confidence',0)<.7);gold.update(g)
  facets.update(g)
  if a.get('grade',0)>=2 and a.get('confidence',0)>=.7:facets.update(a.get('facets',[]))
 count=len(q['references']) if q['source'].startswith('Hotpot') else 1
 out={'shown':len(menu),'facet_coverage':len(facets)/count,'gold_coverage':len(gold)/count,'offtopic':sum(off)/max(1,len(menu)),'uncertain':sum(unknown)/max(1,len(menu)),'bytes':len(json.dumps([{k:r[k] for k in ['url','title','snippet']} for r in menu],ensure_ascii=False,separators=(',',':')).encode())}
 for k in [3,5,10]:
  out['useful_count'+str(k)]=sum(grades[:k]);out['precision'+str(k)]=sum(grades[:k])/max(1,min(k,len(menu)));out['useful_any'+str(k)]=any(grades[:k]);out['highconf_count'+str(k)]=sum(high[:k])
 _METRICS[cachekey]=dict(out)
 return out

def config_key(c):return json.dumps(c,sort_keys=True,separators=(',',':'))
def configs():
 for p,c,pair,policy in itertools.product([5,10,20],[0,2,3,5],[['bing','brave'],['bing','yahoo']],['never','always','failure','suspect','broader']):
  for order,weight,protect in [('source',1,0)]+[('rrf',w,k) for w,k in itertools.product([.1,.25,.5,1],[0,1,3])]:yield {'primary':p,'contribution':c,'backups':pair,'policy':policy,'order':order,'weight':weight,'protect':protect}
def menu_for(q,source,c,broader=False):
 primary=source['ddg'];failure=len(primary)<3;bad=suspect(q,primary)
 use=c['contribution']>0 and (c['policy']=='always' or c['policy']=='failure' and failure or c['policy']=='suspect' and (failure or bad) or c['policy']=='broader' and broader)
 chosen={'ddg':primary,**{name:source[name] for name in c['backups'] if use}}
 pool={};provenance=collections.defaultdict(dict)
 for provider,rows in chosen.items():
  for row in rows:pool.setdefault(row['key'],row);provenance[row['key']][provider]=row['rank']
 if c['order']=='rrf':
  scores={key:sum((1 if provider=='ddg' else c['weight'])/(60+rank) for provider,rank in ranks.items()) for key,ranks in provenance.items()}
  ordered=sorted(pool.values(),key=lambda r:-scores[r['key']]);prefix=primary[:c['protect']];seen={r['key'] for r in prefix};ordered=prefix+[r for r in ordered if r['key'] not in seen]
 else:ordered=list(pool.values())
 counts=collections.Counter();out=[]
 for r in ordered:
  origins=provenance[r['key']]
  if 'ddg' in origins:
   if counts['ddg']>=c['primary']:continue
   counts['ddg']+=1
  else:
   available=[name for name in c['backups'] if name in origins and counts[name]<c['contribution']]
   if not available:continue
   counts[available[0]]+=1
  out.append(r)
 return out,{'backup_requested':use,'failure':failure,'suspect':bad,'family_counts':dict(counts)}

def evaluate(split='development',broader=False):
 questions=[q for q in json.loads((ROOT/'questions.json').read_text()) if q['split']==split];inputs=[]
 for q in questions:
  capture=json.loads((ROOT/'captures'/(q['id']+'.json')).read_text());source=lists(capture);annotations={r['key']:r for r in json.loads((ROOT/'labels'/(q['id']+'.json')).read_text())['labels']};inputs.append((q,capture,source,annotations))
 baseline={}
 for q,cap,source,annotations in inputs:baseline[q['id']]=metrics(source['ddg'][:10],q,annotations)
 results=[]
 for c in configs():
  ms=[];requests=[]
  for q,cap,source,annotations in inputs:
   menu,plan=menu_for(q,source,c,broader);m=metrics(menu,q,annotations);m['backup_requested']=plan['backup_requested'];m['backup_http_requests']=sum(VERIFIED[q['id']][n]['http_requests'] for n in c['backups']) if plan['backup_requested'] else 0;ms.append(m)
  aggregate={k:statistics.mean(m[k] for m in ms) for k in ms[0]};aggregate['delta_precision3']=aggregate['precision3']-statistics.mean(m['precision3'] for m in baseline.values());aggregate['delta_offtopic']=aggregate['offtopic']-statistics.mean(m['offtopic'] for m in baseline.values())
  results.append({'config':c,'metrics':aggregate})
 return results,baseline,inputs
if __name__=='__main__':
 assert len(list((ROOT/'labels').glob('*.json')))==120,'All120 labels required before selection'
 summaries={};selected={}
 for broader,name in [(False,'normal'),(True,'broader')]:
  results,baseline,inputs=evaluate('development',broader)
  eligible=[r for r in results if r['metrics']['delta_precision3']>=-.03 and r['metrics']['delta_offtopic']<=.02]
  small=[r for r in eligible if r['config']['primary']+2*r['config']['contribution']<=16];best_small=max(r['metrics']['facet_coverage'] for r in small)
  if not broader:eligible=[r for r in eligible if r['config']['primary']+2*r['config']['contribution']<=16 or r['metrics']['facet_coverage']>=best_small+.03]
  best=max(r['metrics']['facet_coverage'] for r in eligible);short=[r for r in eligible if r['metrics']['facet_coverage']>=best-.01]
  picked=min(short,key=lambda r:(r['metrics']['backup_http_requests'],r['metrics']['bytes'],r['config']['contribution'],r['config']['primary'],0 if r['config']['order']=='source' else 1,r['config']['protect']))
  selected[name]=picked;summaries[name]=sorted(results,key=lambda r:(-r['metrics']['facet_coverage'],-r['metrics']['precision3']))
 (ROOT/'development-grid.json').write_text(json.dumps(summaries,indent=2)+'\n')
 # Lock selection BEFORE reading held-out metrics.
 (ROOT/'selection-lock.json').write_text(json.dumps({'selected':selected,'time':time.time(),'questions_sha256':hashlib.sha256((ROOT/'questions.json').read_bytes()).hexdigest(),'protocol_sha256':hashlib.sha256((ROOT/'protocol.json').read_bytes()).hexdigest()},indent=2)+'\n')
 print(json.dumps(selected,indent=2))
