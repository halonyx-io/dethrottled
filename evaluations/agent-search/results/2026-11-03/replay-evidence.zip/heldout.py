import json,statistics,random,collections
from pathlib import Path
from replay import lists,menu_for,metrics,VERIFIED
R=Path(__file__).parent
lock=json.loads((R/'selection-lock.json').read_text())
base=dict(primary=10,contribution=0,backups=['bing','brave'],policy='never',order='source',weight=1,protect=0)
configs={'locked_normal':lock['selected']['normal']['config'],'locked_broader':lock['selected']['broader']['config'],'ddg5':dict(base,primary=5),'ddg10':base,'ddg20':dict(base,primary=20),'hypothesis_source':dict(base,contribution=3,policy='always'),'hypothesis_rrf60':dict(base,contribution=3,policy='always',order='rrf'),'bing_yahoo_source':dict(base,backups=['bing','yahoo'],contribution=3,policy='always'),'bing_yahoo_rrf60':dict(base,backups=['bing','yahoo'],contribution=3,policy='always',order='rrf')}
questions=[q for q in json.loads((R/'questions.json').read_text()) if q['split']=='heldout']
rows=[]
for q in questions:
 cap=json.loads((R/'captures'/(q['id']+'.json')).read_text());source=lists(cap);ann={r['key']:r for r in json.loads((R/'labels'/(q['id']+'.json')).read_text())['labels']}
 row={'id':q['id'],'question':q['question'],'category':q.get('category',q['source']),'source':q['source'],'variants':{}}
 for name,c in configs.items():
  menu,plan=menu_for(q,source,c,name=='locked_broader');m=metrics(menu,q,ann)
  m['backup_http_requests']=sum(VERIFIED[q['id']][p]['http_requests'] for p in c['backups']) if plan['backup_requested'] else 0
  row['variants'][name]={'metrics':m,'menu':[dict(r,provider_ranks={p:next(x['rank'] for x in ls if x['key']==r['key']) for p,ls in source.items() if any(x['key']==r['key'] for x in ls)}) for r in menu],'plan':plan}
 rows.append(row)
aggregate={n:{k:statistics.mean(r['variants'][n]['metrics'][k] for r in rows) for k in rows[0]['variants'][n]['metrics']} for n in configs}
rng=random.Random(31103);indices=[[rng.randrange(len(rows)) for _ in rows] for _ in range(10000)]
comparisons={}
for name in configs:
 comparisons[name]={}
 for key in ['facet_coverage','gold_coverage','precision3','useful_count5','useful_count10','offtopic','bytes','backup_http_requests']:
  ds=[r['variants'][name]['metrics'][key]-r['variants']['ddg10']['metrics'][key] for r in rows];bs=sorted(sum(ds[i] for i in ix)/len(ix) for ix in indices)
  comparisons[name][key]={'mean_delta':statistics.mean(ds),'paired_query_bootstrap_95':[bs[249],bs[9749]],'wins':sum(d>1e-9 for d in ds),'losses':sum(d< -1e-9 for d in ds),'ties':sum(abs(d)<=1e-9 for d in ds)}
groups={}
for cat in sorted({r['category'] for r in rows}):
 subset=[r for r in rows if r['category']==cat];groups[cat]={'n':len(subset),'variants':{n:{k:statistics.mean(r['variants'][n]['metrics'][k] for r in subset) for k in ['facet_coverage','gold_coverage','precision3','useful_count5','offtopic']} for n in configs}}
output={'selection_lock':lock,'n':len(rows),'configs':configs,'aggregate':aggregate,'comparisons_vs_ddg10':comparisons,'categories':groups,'per_query':rows,'limitations':['Snippet usefulness and facet judgements are model assisted, not human verified accuracy.','95% intervals quantify query sampling uncertainty only, not judge bias.','Full captured provider lists are fixed; backup request costs are observed counts replayed conditionally, not live policy latency.','Heldout baselines are prespecified menu/provider/ranking comparisons, not a grid used to retune.']}
(R/'heldout-results.json').write_text(json.dumps(output,indent=2)+'\n')
for n,m in aggregate.items():print(n,{k:round(m[k],4) for k in ['facet_coverage','gold_coverage','precision3','useful_count5','useful_count10','offtopic','backup_http_requests']})
