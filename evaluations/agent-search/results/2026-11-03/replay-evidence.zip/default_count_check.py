import json,statistics
from pathlib import Path
from replay import lists,metrics
R=Path(__file__).parent;out=[]
for q in json.loads((R/'questions.json').read_text()):
 source=lists(json.loads((R/'captures'/(q['id']+'.json')).read_text()));ann={r['key']:r for r in json.loads((R/'labels'/(q['id']+'.json')).read_text())['labels']}
 out.append({'id':q['id'],'split':q['split'],'eight':metrics(source['ddg'][:8],q,ann),'ten':metrics(source['ddg'][:10],q,ann)})
summary={}
for split in ['development','heldout']:
 rs=[r for r in out if r['split']==split];summary[split]={n:{k:statistics.mean(r[n][k] for r in rs) for k in rs[0][n]} for n in ['eight','ten']}
(R/'default-count-check.json').write_text(json.dumps({'note':'Supplementary descriptive check of existing HTTP default8 vs selected10, after locked selection. Not used to retune the selected policy. MCP already defaults10. Identical frozen DDG lists; not live full-API quality validation.','summary':summary,'per_query':out},indent=2)+'\n')
print({s:{n:round(m['facet_coverage'],4) for n,m in ms.items()} for s,ms in summary.items()})
