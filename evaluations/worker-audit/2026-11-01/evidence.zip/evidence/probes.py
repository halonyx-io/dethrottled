import concurrent.futures,json,subprocess,time
from pathlib import Path
ROOT=Path(__file__).parent
code=r'''
import concurrent.futures,json,os,time,requests
from dethrottled import fetch
records=[]
def probe(label,url,method='GET',**kwargs):
 started=time.monotonic()
 try:
  response=requests.request(method,url,timeout=100,**kwargs)
  content_type=response.headers.get('Content-Type','')
  data=response.json() if 'json' in content_type else {'bytes':len(response.content),'pdf_magic':response.content.startswith(b'%PDF')}
  row={'case':label,'status':response.status_code,'elapsed_ms':round((time.monotonic()-started)*1000),'result':data}
 except Exception as exc:row={'case':label,'error':type(exc).__name__,'elapsed_ms':round((time.monotonic()-started)*1000)}
 return row
for name,url in [('browser-health','http://browser-search:19888/health'),('browser-metrics','http://browser-search:19888/metrics'),('layout-health','http://docling-worker:19891/health'),('media-health','http://media-worker:19889/health'),('renderer-health','http://crawl4ai:11235/health'),('pdf-health','http://pdf-worker:8788/health')]:records.append(probe(name,url))
records.append(probe('offline-html-to-pdf','http://pdf-worker:8788/pdf','POST',json={'html':'<!doctype html><style>@page{size:A4}</style><h1>Worker audit</h1><p>ALPHA allocation is 7341 tonnes.</p>','format':'A4'}))
records.append(probe('headed-ddg','http://browser-search:19888/search','POST',json={'query':'Python sqlite3 official documentation'}))
def engine(name):
 r=probe('searxng-'+name,'http://searxng:8080/search',params={'q':'Python SQLite database' if 'news' not in name else 'technology','format':'json','engines':name})
 data=r.get('result',{})
 if isinstance(data,dict):r['result']={'count':len(data.get('results',[])),'errors':data.get('unresponsive_engines',[]),'engines':sorted({e for row in data.get('results',[]) for e in row.get('engines',[])})}
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as p:records.extend(p.map(engine,['mwmbl','crossref','openalex','arxiv','duckduckgo news','bing news']))
records.append(probe('js-render-via-api','http://127.0.0.1:8787/fetch','POST',json={'urls':['https://quotes.toscrape.com/js/'],'render':'always','recovery':'manual','fresh':True,'max_chars':12000}))
records.append(probe('corpus-status','http://127.0.0.1:8787/corpus/stats'))
print(json.dumps(records))
'''
start=time.monotonic()
done=subprocess.run(['sudo','-n','docker','exec','-i','dethrottled-dethrottled-1','python','-'],input=code,text=True,capture_output=True,check=True)
rows=json.loads(next(l for l in done.stdout.splitlines() if l.startswith('[{')))
(ROOT/'probes.json').write_text(json.dumps(rows,indent=2))
for row in rows:
 result=row.get('result',{})
 if row['case']=='headed-ddg':result={'ok':result.get('ok'),'engine':result.get('engine'),'count':len(result.get('results',[]))}
 if row['case']=='js-render-via-api':result=[{k:x.get(k) for k in ['quality','tier','failure_reason']} for x in result]
 print(row['case'],row.get('status'),row['elapsed_ms'],result)
