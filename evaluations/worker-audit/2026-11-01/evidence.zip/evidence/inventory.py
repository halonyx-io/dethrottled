import subprocess,json,concurrent.futures,urllib.request
from pathlib import Path
ROOT=Path(__file__).parent
NAMES=['dethrottled-dethrottled-1','dethrottled-browser-search-1','dethrottled-docling-worker-1','dethrottled-media-worker-1','dethrottled-crawl4ai-1','dethrottled-pdf-worker-1','dethrottled-searxng-1']
PACKAGES=['dethrottled','crawl4ai','patchright','playwright','docling','torch','torchvision','faster-whisper','ctranslate2','fastapi','uvicorn','pymupdf','resiliparse','tokenizers','onnxruntime']
code='import importlib.metadata as m,json;names='+repr(PACKAGES)+';installed={d.metadata["Name"].lower().replace("_","-"):d.version for d in m.distributions()};print(json.dumps({n:installed[n] for n in names if n in installed}))'
def inspect(name):
 data=json.loads(subprocess.check_output(['sudo','-n','docker','inspect',name]))[0]
 info={'name':name,'image_id':data['Image'],'image_name':data['Config']['Image'],'started':data['State']['StartedAt'],'restarts':data['RestartCount'],'oom_killed':data['State']['OOMKilled'],'health':data['State'].get('Health',{}).get('Status','not_configured'),'limits':{k:data['HostConfig'].get(k) for k in ['Memory','NanoCpus','PidsLimit','ShmSize']}}
 try:info['versions']=json.loads(subprocess.check_output(['sudo','-n','docker','exec',name,'python','-c',code],text=True,stderr=subprocess.DEVNULL))
 except subprocess.CalledProcessError:info['versions']='python executable unavailable; inspected separately'
 return info
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(inspect,NAMES))
(ROOT/'inventory.json').write_text(json.dumps(rows,indent=2))
def latest(name):
 try:
  with urllib.request.urlopen('https://pypi.org/pypi/'+name+'/json',timeout=20) as r:data=json.load(r)
  return {'name':name,'latest':data['info']['version'],'requires_python':data['info'].get('requires_python')}
 except Exception as e:return {'name':name,'error':type(e).__name__}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:upstream=list(pool.map(latest,['crawl4ai','patchright','docling','faster-whisper','ctranslate2','fastapi','uvicorn','pymupdf','onnxruntime','kreuzberg']))
(ROOT/'upstream-pypi.json').write_text(json.dumps(upstream,indent=2))
print(json.dumps({'workers':rows,'upstream':upstream},indent=2))
